URL_SERVICE = "https://ce925e7e-b0ec-4266-8793-c302661cb648.serverhub.praktikum-services.ru"
CREATE_ORDER_PATH = "/api/v1/orders"
GET_ORDER_BY_NUMBER_PATH = "/api/v1/orders/track"